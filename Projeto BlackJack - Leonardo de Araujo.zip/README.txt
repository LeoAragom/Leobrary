INSTRU��ES DE USO DO PROJETO.

O seguinte projeto apresentado (BlackJack), foi desenvolvido no compilador NetBeans.
Para que seja poss�vel utiliz�-lo, realize os passos a seguir:

1 - Extraia o arquivo para uma pasta de f�cil acesso.

2 - Abra o compilador (NetBeans).

3 - Acesse o projeto (BlackJack) a partir do compilador em File, Open Project, (Pasta Selecionada para a extra��o).

4 - Abra a classe principal "UsaBlackJack.java" e inicie o projeto, na maior seta verde localizada na parte superior do NetBeans, ou ent�o no atalho padr�o F6.